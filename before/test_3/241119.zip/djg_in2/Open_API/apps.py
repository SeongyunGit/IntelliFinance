from django.apps import AppConfig


class OpenApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Open_API'
